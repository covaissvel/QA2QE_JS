function reverse()
{
   //fill your code here
 }