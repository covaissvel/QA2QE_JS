
function addCompanyQuote() {
   // Fill your code here 
}
function displayAll() {
    
    // Fill your code here 
}
function displayLowestQuotedCompany() { 

   // Fill your code here 
    
}
function displayHighestQuotedCompany() {
    // Fill your code here 
}

function sortBasedOnCost(arr) {
     // Fill your code here 
}
