       
function addPolicy(){           

//Fill code here 
}
function displayPolicy()
{
//Fill code here 
}
