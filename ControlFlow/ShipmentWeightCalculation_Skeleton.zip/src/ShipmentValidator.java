public class ShipmentValidator{

//FIll your code here.

}
