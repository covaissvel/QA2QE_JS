function calculate()
{
   //fill your code here
}