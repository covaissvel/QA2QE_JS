function dateValidate()
{
	<!-- fill code here -->
}
		