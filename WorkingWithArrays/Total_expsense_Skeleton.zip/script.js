function add()
{
   //fill your code here
}

function calculate()
{
   //fill your code here
}