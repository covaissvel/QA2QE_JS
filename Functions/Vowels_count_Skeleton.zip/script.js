function getVowels() 
	 {
	
         //fill code here
	}
