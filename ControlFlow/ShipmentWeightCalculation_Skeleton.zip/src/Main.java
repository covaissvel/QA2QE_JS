public class Main {
	public static void main(String args[]) throws NumberFormatException,
			IOException {
		Logger log = Logger.getLogger("org.hibernate");
		log.setLevel(Level.OFF);
		System.setProperty("org.apache.commons.logging.Log",
				"org.apache.commons.logging.impl.NoOpLog");
		
		//FIll your code here.
	}

	private static int generateShipmentId(int id) {
		//Fill your code here.
	}
}

