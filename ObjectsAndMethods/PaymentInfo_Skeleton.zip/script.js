function validate() {
	// fill your code here
}
function  proceedPayment(){
   	// fill your code here
}

